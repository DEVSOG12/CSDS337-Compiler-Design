# Programming Assignment 1


### Name: Oreofe Solarin
### Case ID: ons8

## Introduction
This is the first programming assignment for the course. I edited the dragon-front-source  compiler code to support for Loops and div operator (Integer Division)

## How to run
1. Clone the repository
2. Run the following command to compile the code
```bash 
make clean
make
```
