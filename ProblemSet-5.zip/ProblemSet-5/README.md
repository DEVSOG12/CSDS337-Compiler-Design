## Optimization Problem Set

### Running Instruction

Architecture needs to be adjusted if not running on MacOS

- Change directory to `src/program`
- Run `make clean`
- Run `make run`

--- 
To run analyis: refer to `analysis.ipynb`


